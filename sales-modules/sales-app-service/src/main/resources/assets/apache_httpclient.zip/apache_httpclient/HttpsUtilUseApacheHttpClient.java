package com.unionpay.acp.sdk;

import javax.net.ssl.*;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpClientError;
import org.apache.commons.httpclient.HttpMethodBase;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.ProxyHost;
import org.apache.commons.httpclient.methods.ByteArrayRequestEntity;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpConnectionParams;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;
import org.apache.log4j.Logger;


import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.*;
import java.security.cert.X509Certificate;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

/**
 * Created by pridas on 2017/9/9.
 */
public class HttpsUtilUseApacheHttpClient {

    private static final Logger logger = Logger.getLogger(HttpsUtilUseApacheHttpClient.class);
    public static final String METHOD_GET = "GET";
    public static final String METHOD_POST = "POST";
    
	static{
		Protocol myhttps = new Protocol("https", new TrustAllSSLSocketFactory(), 443);
		Protocol.registerProtocol("uhttps", myhttps);
		
		//设置代理
//		setProxy("172.16.1.245", 8080);
	}

	private static ProxyHost proxy;
	public static void setProxy(String ip, int port){
		proxy = new ProxyHost(ip, port);
	}
	
    public static byte[] send(String urlStr, byte[] data, Map<String, String> reqHeader, String requestMethod){
    	
        boolean unsafeHttps = false;
        if(urlStr.startsWith("uhttps")){
            unsafeHttps = true;
            urlStr = urlStr.substring(1);
        }

    	HttpMethodBase method = null; 
    	try {
	    	if(METHOD_GET.equals(requestMethod))
	    		method = new GetMethod(urlStr);
	    	else if(METHOD_POST.equals(requestMethod)) {
	    		method = new PostMethod(urlStr);
	    		((PostMethod)method).setRequestEntity(new ByteArrayRequestEntity(data));
	    	}
	    	
	    	if(method == null){
	    		throw new RuntimeException("not implemented method: " + requestMethod);
	    	}
	
	        if(data != null)
	        	logger.debug(requestMethod + " to [" + (unsafeHttps?"(unsafe)" : "") + urlStr + "]: " + new String(data));
	        else 
	        	logger.debug(requestMethod + " to [" + (unsafeHttps?"(unsafe)" : "") +  urlStr + "]");
	
	        for(Entry<String, String> kv : reqHeader.entrySet()){
	        	method.addRequestHeader(kv.getKey(), kv.getValue());
	        }
	        HttpClient httpclient = new HttpClient();
	        httpclient.getParams().setConnectionManagerTimeout(15000);// 连接超时时间
			httpclient.getParams().setSoTimeout(90000);// 读取结果超时时间
			if(proxy != null) httpclient.getHostConfiguration().setProxyHost(proxy);
	
			int statusCode = httpclient.executeMethod(method);
			String charset = method.getResponseCharSet();
	        if(charset == null) charset = "UTF-8";
		    byte[] responseBody = method.getResponseBody();
		    
			if (statusCode != HttpStatus.SC_OK) {
				if(responseBody != null)
					logger.error("HTTP RESP[" + statusCode + "]: " + method.getStatusLine() + ", body: " + new String(responseBody, charset));
				else
					logger.error("HTTP RESP[" + statusCode + "]: " + method.getStatusLine());
	            return null;
			}
	        if (responseBody == null) {
	        	logger.debug("HTTP RESP[" + statusCode + "], but with null responsebody???");
	        	return null; 
	        }
	        logger.debug("HTTP RESP[" + statusCode + "]: " + new String(responseBody, charset));
	        return responseBody;
        } catch (Exception e) {
            logger.error("[" + urlStr + "] " + e.getMessage() + " <- " + e.getClass().getName(), e);
        } finally {
            if(method != null){
//                System.out.println("releaseConnection");
      	        method.releaseConnection(); // Release the connection.
            }
        }
        return null;
    }

    public static byte[] post(String url, byte[] data, Map<String, String> reqHeader){
        return send(url, data, reqHeader, "POST");
    }

    public static byte[] post(String url, byte[] data){
        return post(url, data, new TreeMap<String, String>(){
			private static final long serialVersionUID = -2761292859751696874L;
			{
				put("Content-Type", "application/x-www-form-urlencoded");
			}
		});
    }

    public static byte[] get(String url, Map<String, String> reqHeader){
        return send(url, null, reqHeader, "GET");
    }

    public static byte[] get(String url){
        return send(url, null, new TreeMap<String, String>(){
			private static final long serialVersionUID = -7225134807859941048L;
			{
	            put("Content-Type", "application/x-www-form-urlencoded");
	        }
		}, "GET");
    }

    static class TrustAllSSLSocketFactory implements ProtocolSocketFactory {
    	
        private SSLContext getSSLContext() {
            return createEasySSLContext();
        }

    	TrustAllSSLSocketFactory() {
    	}

    	private static SSLContext createEasySSLContext() {
    		try {
    			SSLContext context = SSLContext.getInstance("TLS");
    			context.init(null, new TrustManager[] { new MyX509TrustManager() },
    					null);
    			return context;
    		} catch (Exception e) {
    			throw new HttpClientError(e.toString());
    		}
    	}

    	public Socket createSocket(String host, int port, InetAddress clientHost,
    			int clientPort) throws IOException, UnknownHostException {
    		return getSSLContext().getSocketFactory().createSocket(host, port,
    				clientHost, clientPort);
    	}

    	public Socket createSocket(String host, int port, InetAddress localAddress,
    			int localPort, HttpConnectionParams params) throws IOException,
    			UnknownHostException {
    		return createSocket(host, port, localAddress, localPort);
    	}

    	public Socket createSocket(String host, int port) throws IOException,
    			UnknownHostException {
    		return getSSLContext().getSocketFactory().createSocket(host, port);
    	}

    	public boolean equals(Object obj) {
    		return ((obj != null) && obj.getClass()
    				.equals(TrustAllSSLSocketFactory.class));
    	}

    	public int hashCode() {
    		return TrustAllSSLSocketFactory.class.hashCode();
    	}

    	public static class MyX509TrustManager implements X509TrustManager {
    		public MyX509TrustManager() {
    		}

    		public X509Certificate[] getAcceptedIssuers() {
    			return null;
    		}

    		public void checkClientTrusted(X509Certificate[] chain, String authType) {
    		}

    		public void checkServerTrusted(X509Certificate[] chain, String authType) {
    		}
    	}
    }


    public static void main(String[] args) throws UnsupportedEncodingException {
    	for(int i=0;i<10000;i++){
    		byte[] bs = post("https://gateway.test.95516.com/gateway/api/appTransReq.do", "accessType=0&bizType=000000&txnSubType=00&signature=ff3e9d82a5528ad51c5b3bde5fd2d62a8e016a68d28abb584140ad2d2baa2c2a&orderId=2019112215532700000154&reqReserved=%7Btestcase%3DTestCase_90_DF%7D&txnTime=20191122155327&txnType=00&merId=777290058990000&encoding=UTF-8&version=5.1.0&signMethod=12".getBytes());
    		System.out.println("" + i + " " + (bs == null ? "null" : new String(bs)));
    		if(i%100==0)System.gc();
    	}
    }

	

}















